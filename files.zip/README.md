# 📰 NEWS SENDER – Automated AI-Powered Daily News Digest

Welcome to **NEWS SENDER** – your automated workflow for fetching, summarizing, and emailing the latest World and Tech news with the help of AI!  
Stay informed every day without lifting a finger, thanks to n8n and AI magic. ✨  

---

## 🚀 Project Overview

**NEWS SENDER** is an n8n workflow designed to automatically gather fresh World and Tech news from trusted RSS feeds, synthesize the top stories using an AI language model, and email you a beautiful, concise summary every day.  
Perfect for busy professionals, news enthusiasts, or anyone who wants their news filtered, friendlier, and free of fluff.

---

## 🧩 Node by Node: How It Works

### 1. **Trigger**  
- **Schedule Trigger** (`Run every day at 7AM`):  
  Fires automatically each morning (or you can trigger manually).

### 2. **Fetch News Feeds**
- **Get Tech News**:  
  Grabs the latest technology stories from [The Verge Tech RSS](https://www.theverge.com/rss/index.xml).
- **Get World News**:  
  Retrieves global headlines from [BBC World News RSS](https://feeds.bbci.co.uk/news/world/rss.xml).

### 3. **AI Summarization**
- **OpenAI Model**:  
  Connects to the GPT-4.1-mini language model via OpenAI.
- **AI Summary Agent**:  
  Uses this prompt:  
  > "Summarize world news and tech news from the last 24 hours.  
  > Skip your comments.  
  > The titles should be 'World news:' and 'Tech news:'  
  > Today is {{ $today }}"

  **Result:** The AI processes all fetched articles, generating two sections:  
  - World news
  - Tech news  
  (No editorializing—just the info!)

### 4. **Prepare Email Output**
- **Output**:  
  Collects the AI's summary and formats it for emailing.

### 5. **Send by Email**
- **Send summary by email**:  
  Automatically delivers the final news digest to your chosen inbox (e.g., `thinkerytech@gmail.com`).

---

## 🗺️ Logic Flow

1. **Trigger** (scheduled or manual).
2. **Fetch both RSS feeds** in parallel.
3. **Pass latest stories** to the AI.
4. **AI creates a terse, friendly, titled plain text summary.**
5. **Output node collects** the AI's summary.
6. **Gmail node sends** the digest via email.

---

## 🤖 The AI's Personality & Goal

- **Persona:** Objective, concise, structured, and friendly—no personal opinions.
- **Output Goal:**  
  - Provide a daily snapshot of important World and Tech events for busy readers.
  - Two clear sections, both straight-to-the-point.

---

## 🛠️ Technical Requirements

To run this workflow, you’ll need:

- **n8n** (self-hosted or cloud)
- **OpenAI API credentials** (for GPT-4/4.1-mini access)
- **Gmail account with OAuth2** (for sending automatic emails)
- (Optional) Knowledge of adjusting triggers and email recipients in n8n

---

## 💡 Getting Started

1. **Import the `NEWS SENDER.json` workflow INTO n8n.**
2. **Connect your OpenAI** and **Gmail credentials**.
3. **Adjust schedule** or manual trigger as you wish.
4. Hit **execute** or let it run daily!
5. Start each day with a modern, AI-generated news summary in your inbox! 🚀

---

## 📢 Bonus Tips

- **Edit recipient email** in the Gmail node to fit your needs.
- Pull more news sources or different topics—just add additional RSS nodes!
- Customize the AI prompt to personalize the digest style (formal, casual, etc.).

---

## 👥 Author

Built with ❤️ by [sahilgoury7](https://github.com/sahilgoury7).

---

## 📎 Resources

- [The Verge Tech RSS](https://www.theverge.com/rss/index.xml)
- [BBC World RSS](https://feeds.bbci.co.uk/news/world/rss.xml)
- [n8n Documentation](https://docs.n8n.io/)

---

Enjoy your smarter inbox!  